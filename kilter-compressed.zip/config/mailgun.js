module.exports = {
  domain: '',
  apiKey: '',
  from: ''
};