module.exports = {
  // clientID: '136750067127417', // My Kilter+ App
  // clientSecret: '2997baa207174350746972fa4e36cac7',

  clientID: '1852889894780995', // Salil Developer App
  clientSecret: '1161e00642083f40ae933bd78d1d7899',
};