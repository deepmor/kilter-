module.exports = {
  'secret': 'mynodesecretforkilter',
  'database': 'mongodb://localhost:27017/kilter',
};