module.exports = {
  // clientId: '81vninpszytat9', // Mine
  // clientSecret: 'HQKyZgn6eF6ZC29I',

  clientId: '81ldynzq2g8csc', // Salil
  clientSecret: 'gcx21vjtl6x7MzOJ',
};